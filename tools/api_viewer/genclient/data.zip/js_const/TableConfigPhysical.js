

var TableConfigPhysical = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	BUY_PHYSICAL_PRICE : 50,
	BUY_PHYSICAL_VALUE : 200,
	PHYSICAL_RECOVER_SECOND : 300,
	PER_RECOVER_PHYSICAL_VALUE : 1,
	DAILY_PHYSICAL_BUY_COUNT : 1,
	MAX_PHYSICAL_VALUE_BY_TIME : 200,
	MAX_PHYSICAL_VALUE : 2000,
	

};