

var TableConfigBattle_item = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	TARGET_TYPE_SELF : 1,
	TARGET_TYPE_US_ALL : 2,
	TARGET_TYPE_US_LEAST_HTH : 3,
	TARGET_TYPE_ENEMY_ALL : 4,
	TARGET_TYPE_ENEMY_LEAST_HTH : 5,
	TARGET_TYPE_US_DEAD : 6,
	TARGET_TYPE_BATTLE_PET : 7,
	

	// =====================================================================
	//
	// $config[1]
	//
	// =====================================================================
	
	EFFECT_MODE_POWER : 0,
	EFFECT_MODE_HEALTH : 1,
	EFFECT_MODE_RELIVE : 3,
	EFFECT_MODE_CATCH_PET : 4,
	

	// =====================================================================
	//
	// $config[2]
	//
	// =====================================================================
	
	BATTLE_RECOVER_POWER : 3,
	

};