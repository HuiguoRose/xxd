

var TableConfigTower_level = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	USE_LADDER_COINS_PRICE : 1000,
	MAX_BATTLE_ROUND : 15,
	MAX_FLOOR_NUM : 80,
	MAX_RANK_TOTAL : 100,
	

};