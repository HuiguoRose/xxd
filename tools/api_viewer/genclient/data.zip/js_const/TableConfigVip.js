

var TableConfigVip = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	MAX_VIP_LEVEL : 15,
	

	// =====================================================================
	//
	// $config[1]
	//
	// =====================================================================
	
	AIXINFULI : 1,
	GOUMAITONGQIAN : 8,
	GOUMAITILI : 15,
	BIWUCHANGTEQUAN : 23,
	AIXINCHOUJIANG : 27,
	YINGHAIJISHI : 30,
	PILIANGDUIHUAN : 28,
	CAIHONGTEQUAN : 29,
	ZHUANSHUSHIZHUANG : 37,
	BIWUCHANGCISHU : 39,
	ZIYUANGUANQIASAODANG : 41,
	YUNHAITEQUAN : 42,
	JUEWANGZHIDI : 43,
	HUNSHISHENGXING : 40,
	

};