

var TableConfigRole = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	MAIN_ROLE : 1,
	MAX_ROLE_NUM : 5,
	MAX_ROLE_NUM_USING : 9,
	PLAYER_BOY_ROLE_ID : 1,
	PLAYER_GIRL_ROLE_ID : 2,
	MAX_ROLE_LEVEL : 150,
	MAX_FRISHP_LEVEL : 10,
	ROLE_STATUS_NOMAL : 0,
	ROLE_STATUS_ININN : 1,
	FIGHT_FOR_ALL : 0,
	FIGHT_FOR_ROLE_LEVEL : 1,
	FIGHT_FOR_SKILL : 2,
	FIGHT_FOR_EQUIP : 3,
	FIGHT_FOR_GHOST : 4,
	FIGHT_FOR_REALM : 5,
	FIGHT_FOR_FRIENDSHIP : 6,
	FIGHT_FOR_TEAMSHIP : 7,
	

};