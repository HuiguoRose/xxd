

var TableConfigMeditation = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	EXP_UNIT_TIME : 15,
	KEY_UNIT_TIME : 21600,
	MAX_MEDITATION_TIME : 43200,
	AUTO_MEDITATE_DELAY : 600,
	MEDITATION_STOP : 0,
	CLUBHOUSE_MEDITATION_INFO : 1,
	CLUBHOUSE_MEDITATION_START : 2,
	CLUBHOUSE_MEDITATION_STOP : 3,
	

};