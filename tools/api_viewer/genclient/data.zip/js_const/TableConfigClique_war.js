

var TableConfigClique_war = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	SIGN_UP_START_TIME_DAY : 1,
	SIGN_UP_START_TIME_HOUR : 0,
	SIGN_UP_START_TIME_MINUTE : 0,
	SIGN_UP_END_TIME_DAY : 6,
	SIGN_UP_END_TIME_HOUR : 20,
	SIGN_UP_END_TIME_MINUTE : 0,
	CLIQUE_WAR_TIME_DAY : 7,
	CLIQUE_WAR_TIME_HOUR : 19,
	CLIQUE_WAR_TIME_MINUTE : 30,
	CLIQUE_WAR_DURATION : 1800,
	JOIN_TIME_LIMIT : 86400,
	BATTLE_TIMES_LIMIT : 3,
	CLIQUE_WAR_WINNER_BOX : 899,
	CLIQUE_WAR_WINNER_FAME : 1000,
	CLIQUE_WAR_LOSE_FAME : 100,
	

};