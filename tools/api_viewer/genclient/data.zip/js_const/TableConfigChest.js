

var TableConfigChest = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	FREE_FATE_BOX_CD : 172800,
	FREE_FATE_BOX_FIRST_TIME_CD : 64800,
	FATE_BOX_PRICE : 188,
	FATE_BOX_TEN_TIME_PRICE : 1680,
	FATE_BOX_INIT_CD_TIME : -1,
	

};