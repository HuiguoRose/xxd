

var TableConfigMoney_tree = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	MAX_MONEY : 5000,
	MIN_MONEY : 2000,
	WAVE_TIMES_PER_DAY : 3,
	WAVE_TIMES_NEED_TREE : 6,
	WAVE_GAP_SECONDS : 600,
	

};