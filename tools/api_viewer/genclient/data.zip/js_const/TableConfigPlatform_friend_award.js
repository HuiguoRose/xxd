

var TableConfigPlatform_friend_award = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	AWARD_TYPE_ITEM : 0,
	AWARD_TYPE_COIN : 1,
	AWARD_TYPE_INGOT : 2,
	AWARD_TYPE_HEART : 3,
	AWARD_TYPE_EXP_IN_FORM : 4,
	AWARD_TYPE_GHOST : 6,
	AWARD_TYPE_SWORD_SOUL : 7,
	

};