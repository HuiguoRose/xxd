

var TableConfigMonster_property_addition = 
{

};