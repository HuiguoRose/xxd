

var TableConfigEnemy_role = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	ENEMY_KIND_GOD : 0,
	ENEMY_KIND_FAIRY : 1,
	ENEMY_KIND_HUMAN : 2,
	ENEMY_KIND_BEAST : 3,
	ENEMY_KIND_DAEMON : 4,
	ENEMY_KIND_DEVIL : 5,
	

};