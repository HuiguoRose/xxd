

var TableConfigBattle = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	BATTLE_VERSION : 1,
	

	// =====================================================================
	//
	// $config[1]
	//
	// =====================================================================
	
	BATTLE_RECORD_TAG_DESPAIR_LAND_LATEST_PASS : 1,
	BATTLE_RECORD_TAG_DESPAIR_LAND_FIRST_PASS : 2,
	BATTLE_RECORD_TAG_DESPAIR_LAND_LOW_FIGHT_NUM_PASS : 3,
	

};