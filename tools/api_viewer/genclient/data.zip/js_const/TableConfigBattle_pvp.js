

var TableConfigBattle_pvp = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	INVITE_VAILD_TIME : 30,
	

	// =====================================================================
	//
	// $config[1]
	//
	// =====================================================================
	
	TARGET_STATUS_OFFLINE : 0,
	TARGET_STATUS_NORMAL : 1,
	TARGET_STATUS_PVPING : 2,
	CREATE_INVITE_FAIL : 3,
	

	// =====================================================================
	//
	// $config[2]
	//
	// =====================================================================
	
	INVITE_RESULT_SUCC : 0,
	INVITE_RESULT_INVITER_WATING_FOR_REPLY : 1,
	INVITE_RESULT_INVITER_WATING_FOR_INVITE : 2,
	INVITE_RESULT_TARGET_OFFLINE : 3,
	INVITE_RESULT_TARGET_BUSY : 4,
	

};