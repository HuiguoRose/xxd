

var TableConfigDespair = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	START_EVERY_WEEK_DAY : 1,
	START_EVERY_WEEK_HOUR : 5,
	MAX_BATTLE_NUM : 5,
	MAX_BOSS_LEVEL : 99,
	WAR_POINT : 2,
	DESPAIR_TYPE_IN_MISSION_LEVEL : 19,
	DEC_LEVEL : 1,
	XS_BOSS : 1149,
	SG_BOSS : 1150,
	YM_BOSS : 1148,
	XS_BOSS_LEVEL : 841,
	SG_BOSS_LEVEL : 842,
	YM_BOSS_LEVEL : 843,
	XS : 1,
	SG : 2,
	YM : 3,
	

};