

var TableConfigAwaken = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	ATTR_LEVEL_LIMIT : 10,
	ITEM_HOPES_LIGHT : 822,
	

	// =====================================================================
	//
	// $config[1]
	//
	// =====================================================================
	
	AWAKE_HEALTH : 1,
	AWAKE_ATTACK : 2,
	AWAKE_DEFEND : 3,
	AWAKE_CULTIVATION : 4,
	AWAKE_SPEED : 5,
	AWAKE_SUNDER : 6,
	AWAKE_HITLV : 7,
	AWAKE_DODGELV : 8,
	AWAKE_BLOCKLV : 9,
	AWAKE_DESTORYLV : 10,
	AWAKE_CRITIALLV : 11,
	AWAKE_TENACITYLV : 12,
	AWAKE_POISON : 13,
	AWAKE_DISSKILL : 14,
	AWAKE_SLEEP : 15,
	AWAKE_DIZZINESS : 16,
	AWAKE_RANDOM : 17,
	AWAKE_SPIRIT : 18,
	AWAKE_HUMAN : 19,
	AWAKE_DEVIL : 20,
	

};