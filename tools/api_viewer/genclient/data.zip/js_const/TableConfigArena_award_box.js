

var TableConfigArena_award_box = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	MAX_DAILY_NUM : 8,
	AWARD_ANYINGGUOSHI_WIN_HIGH_RANK : 5,
	AWARD_ANYINGGUOSHI_WIN_LOW_RANK : 3,
	AWARD_ANYINGGUOSHI_LOSE_LOW_RANK : 1,
	LOSE_CD_TIME_SECONDS : 600,
	ARENA_ATTACK_SUCC : 1,
	ARENA_ATTACK_FAILED : 2,
	ARENA_ATTACKED_SUCC : 3,
	ARENA_ATTACKED_FAILED : 4,
	CD_TIME_ONE_MIN_COST_INGOT : 1,
	MAX_RESERVED_RECORD : 20,
	GETBACK_AWARD_BOX_DAY1_COST_INGOT : 10,
	GETBACK_AWARD_BOX_DAY2_COST_INGOT : 20,
	GETBACK_AWARD_BOX_DAY3_COST_INGOT : 40,
	

};