

var TableConfigHeart = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	HEART_INIT_VAL : 2,
	HEART_UPPER : 10,
	HEART_DAY_COUNT_MAX : 99,
	HEART_RECOVER_TIME_INTERVAL : 600,
	HEART_RECOVER_NUM : 1,
	

};