

var TableConfigLevel_func = 
{

	// =====================================================================
	//
	// $config[0]
	//
	// =====================================================================
	
	FUNC_FRIENDSHIP : 1,
	FUNC_DIRECTLY_AWARD : 10,
	FUNC_WORLD_CHANNEL : 15,
	FUNC_MEDITATION : 16,
	FUNC_ARENA : 17,
	FUNC_CLIQUE : 18,
	FUNC_TRADER : 19,
	FUNC_TAOYUAN : 20,
	FUNC_RESOURCE_LEVEL : 25,
	FUNC_PET_VIRTUAL_ENV : 25,
	FUNC_MULTI_LEVEL : 30,
	FUNC_ACTIVE_LEVLE : 35,
	FUNC_TOTEM : 45,
	FUNC_DRIVING_SWORD : 45,
	FUNC_AWAKEN : 50,
	

};