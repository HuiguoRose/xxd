PIModule.Awaken.procAwaken_info = function(dict) {

};

PIModule.Awaken.procLevelup_attr = function(dict) {

};

