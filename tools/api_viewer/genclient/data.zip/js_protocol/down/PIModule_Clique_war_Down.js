PIModule.Clique_war.procWar_info = function(dict) {

};

PIModule.Clique_war.procNotify_war_ready = function(dict) {

};

PIModule.Clique_war.procNotify_war_start = function(dict) {

};

PIModule.Clique_war.procNotify_war_end = function(dict) {

};

PIModule.Clique_war.procSign_up_clique_war = function(dict) {

};

PIModule.Clique_war.procStart_clique_war_battle = function(dict) {

};

PIModule.Clique_war.procSign_up_clique_war_info = function(dict) {

};

