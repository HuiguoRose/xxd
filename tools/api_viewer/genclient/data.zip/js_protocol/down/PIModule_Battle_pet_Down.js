PIModule.Battle_pet.procGet_pet_info = function(dict) {

};

PIModule.Battle_pet.procSet_pet = function(dict) {

};

PIModule.Battle_pet.procSet_pet_swap = function(dict) {

};

PIModule.Battle_pet.procUpgrade_pet = function(dict) {

};

PIModule.Battle_pet.procTraining_pet_skill = function(dict) {

};

