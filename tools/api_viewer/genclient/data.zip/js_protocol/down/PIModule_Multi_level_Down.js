PIModule.Multi_level.procCreate_room = function(dict) {

};

PIModule.Multi_level.procEnter_room = function(dict) {

};

PIModule.Multi_level.procNotify_room_info = function(dict) {

};

PIModule.Multi_level.procLeave_room = function(dict) {

};

PIModule.Multi_level.procNotify_join_partner = function(dict) {

};

PIModule.Multi_level.procChange_buddy = function(dict) {

};

PIModule.Multi_level.procGet_base_info = function(dict) {

};

PIModule.Multi_level.procGet_online_friend = function(dict) {

};

PIModule.Multi_level.procInvite_into_room = function(dict) {

};

PIModule.Multi_level.procNotify_room_invite = function(dict) {

};

PIModule.Multi_level.procNotify_players_info = function(dict) {

};

PIModule.Multi_level.procRefuse_room_invite = function(dict) {

};

PIModule.Multi_level.procNotify_room_invite_refuse = function(dict) {

};

PIModule.Multi_level.procNotify_update_partner = function(dict) {

};

PIModule.Multi_level.procMatch_player = function(dict) {

};

PIModule.Multi_level.procNotify_match_player_success = function(dict) {

};

PIModule.Multi_level.procMatch_room = function(dict) {

};

PIModule.Multi_level.procCancel_match_room = function(dict) {

};

PIModule.Multi_level.procGet_form_info = function(dict) {

};

PIModule.Multi_level.procSet_form = function(dict) {

};

PIModule.Multi_level.procGet_battle_role_info = function(dict) {

};

PIModule.Multi_level.procNotify_match_player_info = function(dict) {

};

PIModule.Multi_level.procGet_match_info = function(dict) {

};

PIModule.Multi_level.procNotify_form_info = function(dict) {

};

PIModule.Multi_level.procCancel_match_player = function(dict) {

};

