PIModule.Fashion.procFashion_info = function(dict) {

};

PIModule.Fashion.procDress_fashion = function(dict) {

};

