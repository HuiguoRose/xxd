PIModule.Player.procInfo = function(dict) {

};

PIModule.Player.procRelogin = function(dict) {

};

PIModule.Player.procBuy_physical = function(dict) {

};

PIModule.Player.procSet_play_key = function(dict) {

};

PIModule.Player.procGet_time = function(dict) {

};

PIModule.Player.procFrom_platform_login = function(dict) {

};

PIModule.Player.procBuy_coins = function(dict) {

};

PIModule.Player.procGet_login_info = function(dict) {

};

PIModule.Player.procCross_login_game_server = function(dict) {

};

PIModule.Player.procNotify_global_server_info = function(dict) {

};

PIModule.Player.procGlobal_login = function(dict) {

};

PIModule.Player.procGet_ingot = function(dict) {

};

PIModule.Player.procSystem_fame = function(dict) {

};

PIModule.Player.procGet_ranks = function(dict) {

};

