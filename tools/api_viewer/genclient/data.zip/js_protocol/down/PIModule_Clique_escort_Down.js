PIModule.Clique_escort.procEscort_info = function(dict) {

};

PIModule.Clique_escort.procGet_ingot_boat = function(dict) {

};

PIModule.Clique_escort.procStart_escort = function(dict) {

};

PIModule.Clique_escort.procHijack_boat = function(dict) {

};

PIModule.Clique_escort.procRecover_boat = function(dict) {

};

PIModule.Clique_escort.procList_boats = function(dict) {

};

PIModule.Clique_escort.procGet_random_boat = function(dict) {

};

PIModule.Clique_escort.procNotify_escort_finished = function(dict) {

};

PIModule.Clique_escort.procNotify_hijack_finished = function(dict) {

};

PIModule.Clique_escort.procNotify_recover_battle_win = function(dict) {

};

PIModule.Clique_escort.procNotify_hijack_battle_win = function(dict) {

};

PIModule.Clique_escort.procTake_hijack_award = function(dict) {

};

PIModule.Clique_escort.procTake_escort_award = function(dict) {

};

PIModule.Clique_escort.procGet_clique_boat_messages = function(dict) {

};

PIModule.Clique_escort.procSend_clique_boat_message = function(dict) {

};

PIModule.Clique_escort.procRead_clique_boat_message = function(dict) {

};

PIModule.Clique_escort.procNotify_boat_status_change = function(dict) {

};

