PIModule.Rainbow.procInfo = function(dict) {

};

PIModule.Rainbow.procReset = function(dict) {

};

PIModule.Rainbow.procAward_info = function(dict) {

};

PIModule.Rainbow.procTake_award = function(dict) {

};

PIModule.Rainbow.procJump_to_segment = function(dict) {

};

PIModule.Rainbow.procAuto_fight = function(dict) {

};

