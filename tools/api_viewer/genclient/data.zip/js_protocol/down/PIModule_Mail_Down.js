PIModule.Mail.procGet_list = function(dict) {

};

PIModule.Mail.procRead = function(dict) {

};

PIModule.Mail.procTake_attachment = function(dict) {

};

PIModule.Mail.procGet_infos = function(dict) {

};

PIModule.Mail.procRequest_global_mail = function(dict) {

};

