PIModule.Clique_quest.procGet_clique_daily_Quest = function(dict) {

};

PIModule.Clique_quest.procAward_clique_daily_Quest = function(dict) {

};

PIModule.Clique_quest.procNotify_clique_daily_change = function(dict) {

};

PIModule.Clique_quest.procGet_clique_building_quest = function(dict) {

};

PIModule.Clique_quest.procAward_clique_building_Quest = function(dict) {

};

