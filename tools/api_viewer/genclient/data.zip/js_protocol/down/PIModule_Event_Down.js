PIModule.Event.procLogin_award_info = function(dict) {

};

PIModule.Event.procTake_login_award = function(dict) {

};

PIModule.Event.procGet_events = function(dict) {

};

PIModule.Event.procGet_event_award = function(dict) {

};

PIModule.Event.procPlayer_event_physical_cost = function(dict) {

};

PIModule.Event.procPlayer_month_card_info = function(dict) {

};

PIModule.Event.procGet_seven_info = function(dict) {

};

PIModule.Event.procGet_seven_award = function(dict) {

};

PIModule.Event.procGet_richman_club_info = function(dict) {

};

PIModule.Event.procGet_richman_club_award = function(dict) {

};

PIModule.Event.procInfo_share = function(dict) {

};

PIModule.Event.procInfo_group_buy = function(dict) {

};

PIModule.Event.procGet_ingot_change_total = function(dict) {

};

PIModule.Event.procGet_event_total_award = function(dict) {

};

PIModule.Event.procGet_event_arena_rank = function(dict) {

};

PIModule.Event.procGet_event_ten_draw_times = function(dict) {

};

PIModule.Event.procGet_event_recharge_award = function(dict) {

};

PIModule.Event.procGet_event_new_year = function(dict) {

};

PIModule.Event.procQq_vip_continue = function(dict) {

};

