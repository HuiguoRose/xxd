PIModule.Mission.procOpen = function(dict) {

};

PIModule.Mission.procGet_mission_level = function(dict) {

};

PIModule.Mission.procEnter_level = function(dict) {

};

PIModule.Mission.procOpen_level_box = function(dict) {

};

PIModule.Mission.procUse_ingot_relive = function(dict) {

};

PIModule.Mission.procUse_item = function(dict) {

};

PIModule.Mission.procRebuild = function(dict) {

};

PIModule.Mission.procEnter_extend_level = function(dict) {

};

PIModule.Mission.procGet_extend_level_info = function(dict) {

};

PIModule.Mission.procOpen_small_box = function(dict) {

};

PIModule.Mission.procNotify_catch_battle_pet = function(dict) {

};

PIModule.Mission.procEnter_hard_level = function(dict) {

};

PIModule.Mission.procGet_hard_level = function(dict) {

};

PIModule.Mission.procGet_buddy_level_role_id = function(dict) {

};

PIModule.Mission.procSet_buddy_level_team = function(dict) {

};

PIModule.Mission.procAuto_fight_level = function(dict) {

};

PIModule.Mission.procEnter_rainbow_level = function(dict) {

};

PIModule.Mission.procOpen_meng_yao = function(dict) {

};

PIModule.Mission.procGet_mission_level_by_item_id = function(dict) {

};

PIModule.Mission.procBuy_hard_level_times = function(dict) {

};

PIModule.Mission.procOpen_random_award_box = function(dict) {

};

PIModule.Mission.procEvaluate_level = function(dict) {

};

PIModule.Mission.procOpen_shaded_box = function(dict) {

};

PIModule.Mission.procGet_mission_total_star_info = function(dict) {

};

PIModule.Mission.procGet_mission_total_star_awards = function(dict) {

};

PIModule.Mission.procClear_mission_level_state = function(dict) {

};

PIModule.Mission.procBuy_resource_mission_level_times = function(dict) {

};

