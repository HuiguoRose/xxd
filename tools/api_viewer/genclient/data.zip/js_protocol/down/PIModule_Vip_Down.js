PIModule.Vip.procInfo = function(dict) {

};

PIModule.Vip.procGet_total = function(dict) {

};

PIModule.Vip.procVip_level_total = function(dict) {

};

PIModule.Vip.procBuy_times = function(dict) {

};

