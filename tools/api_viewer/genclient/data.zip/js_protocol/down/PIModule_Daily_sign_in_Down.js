PIModule.Daily_sign_in.procInfo = function(dict) {

};

PIModule.Daily_sign_in.procSign = function(dict) {

};

PIModule.Daily_sign_in.procSign_past_day = function(dict) {

};

