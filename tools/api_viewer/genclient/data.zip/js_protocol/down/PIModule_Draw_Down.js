PIModule.Draw.procGet_heart_draw_info = function(dict) {

};

PIModule.Draw.procHeart_draw = function(dict) {

};

PIModule.Draw.procGet_chest_info = function(dict) {

};

PIModule.Draw.procDraw_chest = function(dict) {

};

PIModule.Draw.procHeart_info = function(dict) {

};

PIModule.Draw.procGet_fate_box_info = function(dict) {

};

PIModule.Draw.procOpen_fate_box = function(dict) {

};

PIModule.Draw.procExchange_gift_code = function(dict) {

};

