PIModule.Item.procGet_all_items = function(dict) {

};

PIModule.Item.procDrop_item = function(dict) {

};

PIModule.Item.procBuy_item = function(dict) {

};

PIModule.Item.procSell_item = function(dict) {

};

PIModule.Item.procDress = function(dict) {

};

PIModule.Item.procUndress = function(dict) {

};

PIModule.Item.procBuy_item_back = function(dict) {

};

PIModule.Item.procIs_bag_full = function(dict) {

};

PIModule.Item.procDecompose = function(dict) {

};

PIModule.Item.procRefine = function(dict) {

};

PIModule.Item.procGet_recast_info = function(dict) {

};

PIModule.Item.procRecast = function(dict) {

};

PIModule.Item.procUse_item = function(dict) {

};

PIModule.Item.procRole_use_cost_item = function(dict) {

};

PIModule.Item.procBatch_use_item = function(dict) {

};

PIModule.Item.procDragon_ball_exchange_notify = function(dict) {

};

PIModule.Item.procOpen_cornucopia = function(dict) {

};

PIModule.Item.procGet_sealedbooks = function(dict) {

};

PIModule.Item.procActivation_sealedbook = function(dict) {

};

PIModule.Item.procExchange_ghost_crystal = function(dict) {

};

