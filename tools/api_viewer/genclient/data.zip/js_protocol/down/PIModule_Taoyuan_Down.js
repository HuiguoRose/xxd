PIModule.Taoyuan.procTaoyuan_info = function(dict) {

};

PIModule.Taoyuan.procBless = function(dict) {

};

PIModule.Taoyuan.procShop_buy = function(dict) {

};

PIModule.Taoyuan.procShop_sell = function(dict) {

};

PIModule.Taoyuan.procGet_all_items = function(dict) {

};

PIModule.Taoyuan.procFileds_info = function(dict) {

};

PIModule.Taoyuan.procGrow_plant = function(dict) {

};

PIModule.Taoyuan.procTake_plant = function(dict) {

};

PIModule.Taoyuan.procUpgrade_filed = function(dict) {

};

PIModule.Taoyuan.procOpen_filed = function(dict) {

};

PIModule.Taoyuan.procStudy_skill = function(dict) {

};

PIModule.Taoyuan.procMake_product = function(dict) {

};

PIModule.Taoyuan.procTake_product = function(dict) {

};

PIModule.Taoyuan.procProduct_make_queue = function(dict) {

};

PIModule.Taoyuan.procQuest_info = function(dict) {

};

PIModule.Taoyuan.procQuest_finish = function(dict) {

};

PIModule.Taoyuan.procQuest_refresh = function(dict) {

};

PIModule.Taoyuan.procFriend_taoyuan_info = function(dict) {

};

PIModule.Taoyuan.procSkill_info = function(dict) {

};

PIModule.Taoyuan.procOpen_queue = function(dict) {

};

PIModule.Taoyuan.procPlant_quickly_maturity = function(dict) {

};

PIModule.Taoyuan.procTaoyuan_message_info = function(dict) {

};

PIModule.Taoyuan.procTaoyuan_message_read = function(dict) {

};

PIModule.Taoyuan.procOpen_product_building = function(dict) {

};

