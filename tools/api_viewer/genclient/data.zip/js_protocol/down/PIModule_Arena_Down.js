PIModule.Arena.procEnter = function(dict) {

};

PIModule.Arena.procGet_records = function(dict) {

};

PIModule.Arena.procAward_box = function(dict) {

};

PIModule.Arena.procNotify_failed_cd_time = function(dict) {

};

PIModule.Arena.procStart_battle = function(dict) {

};

PIModule.Arena.procNotify_lose_rank = function(dict) {

};

PIModule.Arena.procNotify_arena_info = function(dict) {

};

PIModule.Arena.procGet_top_rank = function(dict) {

};

PIModule.Arena.procClean_failed_cd_time = function(dict) {

};

