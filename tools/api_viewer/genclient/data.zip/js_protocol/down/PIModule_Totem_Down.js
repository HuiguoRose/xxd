PIModule.Totem.procInfo = function(dict) {

};

PIModule.Totem.procCall_totem = function(dict) {

};

PIModule.Totem.procUpgrade = function(dict) {

};

PIModule.Totem.procDecompose = function(dict) {

};

PIModule.Totem.procEquip = function(dict) {

};

PIModule.Totem.procUnequip = function(dict) {

};

PIModule.Totem.procEquip_pos_change = function(dict) {

};

PIModule.Totem.procSwap = function(dict) {

};

PIModule.Totem.procIs_bag_full = function(dict) {

};

