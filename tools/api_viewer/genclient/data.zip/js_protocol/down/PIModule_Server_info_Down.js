PIModule.Server_info.procGet_version = function(dict) {

};

PIModule.Server_info.procGet_api_count = function(dict) {

};

PIModule.Server_info.procSearch_player_role = function(dict) {

};

PIModule.Server_info.procUpdate_access_token = function(dict) {

};

PIModule.Server_info.procUpdate_event_data = function(dict) {

};

PIModule.Server_info.procTss_data = function(dict) {

};

PIModule.Server_info.procPatch_info = function(dict) {

};

