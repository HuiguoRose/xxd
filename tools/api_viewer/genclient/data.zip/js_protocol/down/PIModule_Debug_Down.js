PIModule.Debug.procAdd_buddy = function(dict) {

};

PIModule.Debug.procAdd_item = function(dict) {

};

PIModule.Debug.procSet_role_level = function(dict) {

};

PIModule.Debug.procSet_coins = function(dict) {

};

PIModule.Debug.procSet_ingot = function(dict) {

};

PIModule.Debug.procAdd_ghost = function(dict) {

};

PIModule.Debug.procSet_player_physical = function(dict) {

};

PIModule.Debug.procReset_level_enter_count = function(dict) {

};

PIModule.Debug.procAdd_exp = function(dict) {

};

PIModule.Debug.procOpen_ghost_mission = function(dict) {

};

PIModule.Debug.procSend_mail = function(dict) {

};

PIModule.Debug.procClear_mail = function(dict) {

};

PIModule.Debug.procOpen_mission_level = function(dict) {

};

PIModule.Debug.procStart_battle = function(dict) {

};

PIModule.Debug.procListen_by_name = function(dict) {

};

PIModule.Debug.procOpen_quest = function(dict) {

};

PIModule.Debug.procOpen_func = function(dict) {

};

PIModule.Debug.procAdd_sword_soul = function(dict) {

};

PIModule.Debug.procAdd_battle_pet = function(dict) {

};

PIModule.Debug.procReset_multi_level_enter_count = function(dict) {

};

PIModule.Debug.procOpen_multi_level = function(dict) {

};

PIModule.Debug.procOpen_all_pet_grid = function(dict) {

};

PIModule.Debug.procCreate_announcement = function(dict) {

};

PIModule.Debug.procAdd_heart = function(dict) {

};

PIModule.Debug.procReset_hard_level_enter_count = function(dict) {

};

PIModule.Debug.procOpen_hard_level = function(dict) {

};

PIModule.Debug.procSet_vip_level = function(dict) {

};

PIModule.Debug.procSet_resource_level_open_day = function(dict) {

};

PIModule.Debug.procReset_resource_level_open_day = function(dict) {

};

PIModule.Debug.procReset_arena_daily_count = function(dict) {

};

PIModule.Debug.procReset_sword_soul_draw_cd = function(dict) {

};

PIModule.Debug.procSet_first_login_time = function(dict) {

};

PIModule.Debug.procEarlier_first_login_time = function(dict) {

};

PIModule.Debug.procReset_server_open_time = function(dict) {

};

PIModule.Debug.procClear_trader_refresh_time = function(dict) {

};

PIModule.Debug.procAdd_trader_refresh_time = function(dict) {

};

PIModule.Debug.procClear_trader_schedule = function(dict) {

};

PIModule.Debug.procAdd_trader_schedule = function(dict) {

};

PIModule.Debug.procOpen_town = function(dict) {

};

PIModule.Debug.procAdd_global_mail = function(dict) {

};

PIModule.Debug.procCreate_announcement_without_tpl = function(dict) {

};

PIModule.Debug.procSet_login_day = function(dict) {

};

PIModule.Debug.procReset_login_award = function(dict) {

};

PIModule.Debug.procRest_player_award_lock = function(dict) {

};

PIModule.Debug.procReset_rainbow_level = function(dict) {

};

PIModule.Debug.procSet_rainbow_level = function(dict) {

};

PIModule.Debug.procSend_push_notification = function(dict) {

};

PIModule.Debug.procReset_pet_virtual_env = function(dict) {

};

PIModule.Debug.procAdd_fame = function(dict) {

};

PIModule.Debug.procAdd_world_chat_message = function(dict) {

};

PIModule.Debug.procMonth_card = function(dict) {

};

PIModule.Debug.procEnter_sandbox = function(dict) {

};

PIModule.Debug.procSandbox_rollback = function(dict) {

};

PIModule.Debug.procExit_sandbox = function(dict) {

};

PIModule.Debug.procReset_shaded_missions = function(dict) {

};

PIModule.Debug.procClean_cornucopia = function(dict) {

};

PIModule.Debug.procAdd_totem = function(dict) {

};

PIModule.Debug.procAdd_rune = function(dict) {

};

PIModule.Debug.procSend_rare_item_message = function(dict) {

};

PIModule.Debug.procAdd_sword_driving_action = function(dict) {

};

PIModule.Debug.procReset_driving_sword_data = function(dict) {

};

PIModule.Debug.procAdd_sword_soul_fragment = function(dict) {

};

PIModule.Debug.procReset_money_tree_status = function(dict) {

};

PIModule.Debug.procReset_today_money_tree = function(dict) {

};

PIModule.Debug.procClean_sword_soul_ingot_draw_nums = function(dict) {

};

PIModule.Debug.procPunch_driving_sword_cloud = function(dict) {

};

PIModule.Debug.procClear_clique_daily_donate = function(dict) {

};

PIModule.Debug.procSet_clique_contrib = function(dict) {

};

PIModule.Debug.procRefresh_clique_worship = function(dict) {

};

PIModule.Debug.procClique_escort_hijack_battle_win = function(dict) {

};

PIModule.Debug.procClique_escort_recover_battle_win = function(dict) {

};

PIModule.Debug.procClique_escort_notify_message = function(dict) {

};

PIModule.Debug.procClique_escort_notify_daily_quest = function(dict) {

};

PIModule.Debug.procSet_clique_building_level = function(dict) {

};

PIModule.Debug.procSet_clique_building_money = function(dict) {

};

PIModule.Debug.procEscort_bench = function(dict) {

};

PIModule.Debug.procReset_clique_escort_daily_num = function(dict) {

};

PIModule.Debug.procTake_addition_quest = function(dict) {

};

PIModule.Debug.procSet_mission_star_max = function(dict) {

};

PIModule.Debug.procClique_bank_cd = function(dict) {

};

PIModule.Debug.procReset_despair_land_battle_num = function(dict) {

};

PIModule.Debug.procReset_clique_store_send_times = function(dict) {

};

PIModule.Debug.procAdd_clique_store_donate = function(dict) {

};

PIModule.Debug.procPass_all_despair_land_level = function(dict) {

};

PIModule.Debug.procDespair_land_dummy_boss_kill = function(dict) {

};

PIModule.Debug.procAdd_taoyuan_item = function(dict) {

};

PIModule.Debug.procAdd_taoyuan_exp = function(dict) {

};

