PIModule.Notify.procPlayer_key_changed = function(dict) {

};

PIModule.Notify.procMission_level_lock_changed = function(dict) {

};

PIModule.Notify.procRole_exp_change = function(dict) {

};

PIModule.Notify.procPhysical_change = function(dict) {

};

PIModule.Notify.procMoney_change = function(dict) {

};

PIModule.Notify.procSkill_add = function(dict) {

};

PIModule.Notify.procItem_change = function(dict) {

};

PIModule.Notify.procRole_battle_status_change = function(dict) {

};

PIModule.Notify.procNew_mail = function(dict) {

};

PIModule.Notify.procHeart_change = function(dict) {

};

PIModule.Notify.procQuest_change = function(dict) {

};

PIModule.Notify.procTownLock_change = function(dict) {

};

PIModule.Notify.procChat = function(dict) {

};

PIModule.Notify.procFunc_key_change = function(dict) {

};

PIModule.Notify.procItem_recast_state_rebuild = function(dict) {

};

PIModule.Notify.procSend_announcement = function(dict) {

};

PIModule.Notify.procVip_level_change = function(dict) {

};

PIModule.Notify.procNotify_new_buddy = function(dict) {

};

PIModule.Notify.procHard_level_lock_changed = function(dict) {

};

PIModule.Notify.procSend_sword_soul_draw_num_change = function(dict) {

};

PIModule.Notify.procSend_have_new_ghost = function(dict) {

};

PIModule.Notify.procSend_heart_recover_time = function(dict) {

};

PIModule.Notify.procSend_global_mail = function(dict) {

};

PIModule.Notify.procSend_physical_recover_time = function(dict) {

};

PIModule.Notify.procSend_fashion_change = function(dict) {

};

PIModule.Notify.procTrans_error = function(dict) {

};

PIModule.Notify.procSend_event_center_change = function(dict) {

};

PIModule.Notify.procMeditation_state = function(dict) {

};

PIModule.Notify.procDelete_announcement = function(dict) {

};

PIModule.Notify.procSend_have_new_pet = function(dict) {

};

PIModule.Notify.procSend_logout = function(dict) {

};

PIModule.Notify.procFame_change = function(dict) {

};

PIModule.Notify.procNotify_month_card_open = function(dict) {

};

PIModule.Notify.procNotify_month_card_renewal = function(dict) {

};

PIModule.Notify.procNotify_new_totem = function(dict) {

};

PIModule.Notify.procNotify_rune_change = function(dict) {

};

PIModule.Notify.procTaoyuan_item_change = function(dict) {

};

PIModule.Notify.procTaoyuan_message_refresh = function(dict) {

};

PIModule.Notify.procTaoyuan_quest_can_finish = function(dict) {

};

PIModule.Notify.procTaoyuan_exp_refresh = function(dict) {

};

PIModule.Notify.procBattle_pvp_req = function(dict) {

};

PIModule.Notify.procBattle_pvp_req_refuse = function(dict) {

};

PIModule.Notify.procTown_player_status_change = function(dict) {

};

PIModule.Notify.procStart_pvp_battle = function(dict) {

};

PIModule.Notify.procPvp_req_cancel = function(dict) {

};

