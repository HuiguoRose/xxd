PIModule.Team.procGet_formation_info = function(dict) {

};

PIModule.Team.procUp_formation = function(dict) {

};

PIModule.Team.procDown_formation = function(dict) {

};

PIModule.Team.procSwap_formation = function(dict) {

};

PIModule.Team.procReplace_formation = function(dict) {

};

PIModule.Team.procTraining_teamship = function(dict) {

};

