PIModule.Clique_building.procClique_base_donate = function(dict) {

};

PIModule.Clique_building.procClique_building_status = function(dict) {

};

PIModule.Clique_building.procClique_bank_donate = function(dict) {

};

PIModule.Clique_building.procClique_bank_buy = function(dict) {

};

PIModule.Clique_building.procClique_bank_sold = function(dict) {

};

PIModule.Clique_building.procClique_kongfu_donate = function(dict) {

};

PIModule.Clique_building.procClique_kongfu_info = function(dict) {

};

PIModule.Clique_building.procClique_kongfu_train = function(dict) {

};

PIModule.Clique_building.procClique_temple_worship = function(dict) {

};

PIModule.Clique_building.procClique_temple_donate = function(dict) {

};

PIModule.Clique_building.procClique_temple_info = function(dict) {

};

PIModule.Clique_building.procClique_store_donate = function(dict) {

};

PIModule.Clique_building.procClique_store_info = function(dict) {

};

PIModule.Clique_building.procClique_store_send_chest = function(dict) {

};

