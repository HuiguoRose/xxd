PIModule.Clique.procCreate_clique = function(dict) {

};

PIModule.Clique.procApply_join_clique = function(dict) {

};

PIModule.Clique.procCancel_apply_clique = function(dict) {

};

PIModule.Clique.procProcess_join_apply = function(dict) {

};

PIModule.Clique.procElect_owner = function(dict) {

};

PIModule.Clique.procMange_member = function(dict) {

};

PIModule.Clique.procDestory_clique = function(dict) {

};

PIModule.Clique.procUpdate_announce = function(dict) {

};

PIModule.Clique.procLeave_clique = function(dict) {

};

PIModule.Clique.procList_clique = function(dict) {

};

PIModule.Clique.procClique_public_info = function(dict) {

};

PIModule.Clique.procClique_info = function(dict) {

};

PIModule.Clique.procList_apply = function(dict) {

};

PIModule.Clique.procOpera_error_notify = function(dict) {

};

PIModule.Clique.procEnter_clubhouse = function(dict) {

};

PIModule.Clique.procLeave_clubhouse = function(dict) {

};

PIModule.Clique.procClub_move = function(dict) {

};

PIModule.Clique.procNotify_clubhouse_players = function(dict) {

};

PIModule.Clique.procNotify_new_player = function(dict) {

};

PIModule.Clique.procNotify_update_player = function(dict) {

};

PIModule.Clique.procClique_public_info_summary = function(dict) {

};

PIModule.Clique.procClique_auto_audit = function(dict) {

};

PIModule.Clique.procClique_base_donate = function(dict) {

};

PIModule.Clique.procNotify_leave_clique = function(dict) {

};

PIModule.Clique.procNotify_joinclique_success = function(dict) {

};

PIModule.Clique.procNotify_clique_manger_action = function(dict) {

};

PIModule.Clique.procClique_recruitment = function(dict) {

};

PIModule.Clique.procNotify_clique_announce = function(dict) {

};

PIModule.Clique.procNotify_clique_electowner = function(dict) {

};

PIModule.Clique.procQuick_apply = function(dict) {

};

PIModule.Clique.procNotify_contrib_change = function(dict) {

};

PIModule.Clique.procOther_clique = function(dict) {

};

