PIModule.Pet_virtual_env.procInfo = function(dict) {

};

PIModule.Pet_virtual_env.procTake_award = function(dict) {

};

PIModule.Pet_virtual_env.procAuto_fight = function(dict) {

};

PIModule.Pet_virtual_env.procPve_kills = function(dict) {

};

