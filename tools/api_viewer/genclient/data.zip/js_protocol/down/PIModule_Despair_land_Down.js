PIModule.Despair_land.procDespair_land_info = function(dict) {

};

PIModule.Despair_land.procDespair_land_camp_info = function(dict) {

};

PIModule.Despair_land.procDespair_land_camp_player_info = function(dict) {

};

PIModule.Despair_land.procDespair_land_pick_box = function(dict) {

};

PIModule.Despair_land.procDespair_land_watch_record = function(dict) {

};

PIModule.Despair_land.procDespair_land_buy_battle_num = function(dict) {

};

PIModule.Despair_land.procDespair_land_boss_info = function(dict) {

};

PIModule.Despair_land.procDespair_land_notify_boss_open = function(dict) {

};

PIModule.Despair_land.procDespair_land_notify_boss_dead = function(dict) {

};

PIModule.Despair_land.procDespair_land_buy_boss_battle_num = function(dict) {

};

PIModule.Despair_land.procDespair_land_notify_pass = function(dict) {

};

PIModule.Despair_land.procDespair_land_pick_three_star_box = function(dict) {

};

PIModule.Despair_land.procDespair_land_battle_boss_award_info = function(dict) {

};

PIModule.Despair_land.procDespair_land_boss_open_info = function(dict) {

};

PIModule.Despair_land.procDespair_land_notify_weekly_refresh = function(dict) {

};

