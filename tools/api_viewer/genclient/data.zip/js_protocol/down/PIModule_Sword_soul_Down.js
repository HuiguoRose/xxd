PIModule.Sword_soul.procInfo = function(dict) {

};

PIModule.Sword_soul.procDraw = function(dict) {

};

PIModule.Sword_soul.procUpgrade = function(dict) {

};

PIModule.Sword_soul.procExchange = function(dict) {

};

PIModule.Sword_soul.procEquip = function(dict) {

};

PIModule.Sword_soul.procUnequip = function(dict) {

};

PIModule.Sword_soul.procEquip_pos_change = function(dict) {

};

PIModule.Sword_soul.procSwap = function(dict) {

};

PIModule.Sword_soul.procIs_bag_full = function(dict) {

};

PIModule.Sword_soul.procEmpty_pos_num = function(dict) {

};

