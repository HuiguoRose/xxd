PIModule.Town.procEnter = function(dict) {

};

PIModule.Town.procLeave = function(dict) {

};

PIModule.Town.procMove = function(dict) {

};

PIModule.Town.procTalked_npc_list = function(dict) {

};

PIModule.Town.procNpc_talk = function(dict) {

};

PIModule.Town.procNotify_town_players = function(dict) {

};

PIModule.Town.procUpdate_town_player = function(dict) {

};

PIModule.Town.procUpdate_town_player_meditation_state = function(dict) {

};

PIModule.Town.procList_opened_town_treasures = function(dict) {

};

PIModule.Town.procTake_town_treasures = function(dict) {

};

PIModule.Town.procUpdate_player_status = function(dict) {

};

