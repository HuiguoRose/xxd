PIModule.Clique_boss.procBoss_info = function(dict) {

};

PIModule.Clique_boss.procClique_notify_boss_open = function(dict) {

};

PIModule.Clique_boss.procClique_notify_boss_dead = function(dict) {

};

PIModule.Clique_boss.procClique_battle_boss_award_info = function(dict) {

};

PIModule.Clique_boss.procClique_boss_refresh_challenge = function(dict) {

};

PIModule.Clique_boss.procClique_notify_boss_close = function(dict) {

};

