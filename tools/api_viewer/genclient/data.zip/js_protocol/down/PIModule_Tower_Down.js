PIModule.Tower.procGet_info = function(dict) {

};

PIModule.Tower.procUse_ladder = function(dict) {

};

