PIModule.Trader.procInfo = function(dict) {

};

PIModule.Trader.procStore_state = function(dict) {

};

PIModule.Trader.procBuy = function(dict) {

};

PIModule.Trader.procRefresh = function(dict) {

};

