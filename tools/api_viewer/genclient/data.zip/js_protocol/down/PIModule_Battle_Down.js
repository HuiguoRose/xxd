PIModule.Battle.procStart_battle = function(dict) {

};

PIModule.Battle.procNext_round = function(dict) {

};

PIModule.Battle.procEnd = function(dict) {

};

PIModule.Battle.procEscape = function(dict) {

};

PIModule.Battle.procFightnum = function(dict) {

};

PIModule.Battle.procStart_ready_timeout = function(dict) {

};

PIModule.Battle.procStart_ready = function(dict) {

};

PIModule.Battle.procState_change = function(dict) {

};

PIModule.Battle.procCall_battle_pet = function(dict) {

};

PIModule.Battle.procUse_buddy_skill = function(dict) {

};

PIModule.Battle.procCall_new_enemys = function(dict) {

};

PIModule.Battle.procNew_fighter_group = function(dict) {

};

PIModule.Battle.procStart_battle_for_hijack_boat = function(dict) {

};

PIModule.Battle.procStart_battle_for_recover_boat = function(dict) {

};

PIModule.Battle.procRound_ready = function(dict) {

};

PIModule.Battle.procInit_round = function(dict) {

};

PIModule.Battle.procSet_auto = function(dict) {

};

PIModule.Battle.procCancel_auto = function(dict) {

};

PIModule.Battle.procSet_skill = function(dict) {

};

PIModule.Battle.procUse_item = function(dict) {

};

PIModule.Battle.procUse_ghost = function(dict) {

};

PIModule.Battle.procNotify_ready = function(dict) {

};

PIModule.Battle.procBattle_reconnect = function(dict) {

};

