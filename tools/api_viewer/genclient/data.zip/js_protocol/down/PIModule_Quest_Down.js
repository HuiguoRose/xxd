PIModule.Quest.procUpdate_quest = function(dict) {

};

PIModule.Quest.procGet_daily_info = function(dict) {

};

PIModule.Quest.procAward_daily = function(dict) {

};

PIModule.Quest.procNotify_daily_change = function(dict) {

};

PIModule.Quest.procGuide = function(dict) {

};

PIModule.Quest.procGet_extend_quest_info_by_npc_id = function(dict) {

};

PIModule.Quest.procTake_extend_quest_award = function(dict) {

};

PIModule.Quest.procGet_pannel_quest_info = function(dict) {

};

PIModule.Quest.procGive_up_addition_quest = function(dict) {

};

PIModule.Quest.procTake_addition_quest = function(dict) {

};

PIModule.Quest.procTake_addition_quest_award = function(dict) {

};

PIModule.Quest.procGet_addition_quest = function(dict) {

};

PIModule.Quest.procRefresh_addition_quest = function(dict) {

};

PIModule.Quest.procTake_quest_stars_awaded = function(dict) {

};

