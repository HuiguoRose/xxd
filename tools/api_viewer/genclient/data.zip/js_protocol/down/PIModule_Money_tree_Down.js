PIModule.Money_tree.procGet_tree_status = function(dict) {

};

PIModule.Money_tree.procGet_tree_money = function(dict) {

};

PIModule.Money_tree.procWave_tree = function(dict) {

};

