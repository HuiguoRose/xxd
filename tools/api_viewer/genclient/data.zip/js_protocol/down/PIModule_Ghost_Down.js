PIModule.Ghost.procInfo = function(dict) {

};

PIModule.Ghost.procEquip = function(dict) {

};

PIModule.Ghost.procUnequip = function(dict) {

};

PIModule.Ghost.procSwap = function(dict) {

};

PIModule.Ghost.procEquip_pos_change = function(dict) {

};

PIModule.Ghost.procTrain = function(dict) {

};

PIModule.Ghost.procUpgrade = function(dict) {

};

PIModule.Ghost.procBaptize = function(dict) {

};

PIModule.Ghost.procCompose = function(dict) {

};

PIModule.Ghost.procTrain_skill = function(dict) {

};

PIModule.Ghost.procFlush_attr = function(dict) {

};

PIModule.Ghost.procRelation_ghost = function(dict) {

};

