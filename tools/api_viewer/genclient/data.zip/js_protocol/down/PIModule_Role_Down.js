PIModule.Role.procGet_all_roles = function(dict) {

};

PIModule.Role.procGet_role_info = function(dict) {

};

PIModule.Role.procGet_player_info = function(dict) {

};

PIModule.Role.procGet_fight_num = function(dict) {

};

PIModule.Role.procGet_player_info_with_openid = function(dict) {

};

PIModule.Role.procLevelup_role_friendship = function(dict) {

};

PIModule.Role.procRecruit_buddy = function(dict) {

};

PIModule.Role.procGet_role_fight_num = function(dict) {

};

PIModule.Role.procChange_role_status = function(dict) {

};

PIModule.Role.procGet_inn_role_list = function(dict) {

};

PIModule.Role.procBuddy_coop = function(dict) {

};

