PIModule.Skill.procGet_all_skills_info = function(dict) {

};

PIModule.Skill.procEquip_skill = function(dict) {

};

PIModule.Skill.procUnequip_skill = function(dict) {

};

PIModule.Skill.procStudy_skill_by_cheat = function(dict) {

};

PIModule.Skill.procTrain_skill = function(dict) {

};

PIModule.Skill.procFlush_skill = function(dict) {

};

