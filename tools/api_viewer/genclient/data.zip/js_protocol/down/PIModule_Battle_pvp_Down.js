PIModule.Battle_pvp.procInvite_fight = function(dict) {

};

PIModule.Battle_pvp.procReply_invite = function(dict) {

};

PIModule.Battle_pvp.procEnter_pvp = function(dict) {

};

PIModule.Battle_pvp.procCancel_invite = function(dict) {

};

