PIModule.Channel.procGet_latest_world_channel_message = function(dict) {

};

PIModule.Channel.procAdd_world_chat = function(dict) {

};

PIModule.Channel.procWorld_channel_info = function(dict) {

};

PIModule.Channel.procSend_global_messages = function(dict) {

};

PIModule.Channel.procAdd_clique_chat = function(dict) {

};

PIModule.Channel.procGet_latest_clique_messages = function(dict) {

};

PIModule.Channel.procSend_clique_message = function(dict) {

};

