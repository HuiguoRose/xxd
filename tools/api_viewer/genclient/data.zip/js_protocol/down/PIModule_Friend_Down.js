PIModule.Friend.procGet_friend_list = function(dict) {

};

PIModule.Friend.procListen_by_nick = function(dict) {

};

PIModule.Friend.procCancel_listen = function(dict) {

};

PIModule.Friend.procSend_heart = function(dict) {

};

PIModule.Friend.procChat = function(dict) {

};

PIModule.Friend.procGet_chat_history = function(dict) {

};

PIModule.Friend.procGet_offline_messages = function(dict) {

};

PIModule.Friend.procBlock = function(dict) {

};

PIModule.Friend.procCancel_block = function(dict) {

};

PIModule.Friend.procClean_chat_history = function(dict) {

};

PIModule.Friend.procNotify_listened_state = function(dict) {

};

PIModule.Friend.procCurrent_platform_friend_num = function(dict) {

};

PIModule.Friend.procGet_send_heart_list = function(dict) {

};

PIModule.Friend.procSend_heart_to_all_friends = function(dict) {

};

